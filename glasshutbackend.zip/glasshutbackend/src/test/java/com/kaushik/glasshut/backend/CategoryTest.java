package com.kaushik.glasshut.backend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.kaushik.glasshut.dao.CategoryDAO;
import com.kaushik.glasshut.model.Category;

public class CategoryTest {
 
	public static void main(String[] args)
	{
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.kaushik.glasshutbackend");
		context.refresh();
		
		CategoryDAO catd=(CategoryDAO) context.getBean("categoryDAO");
		Category category = (Category) context.getBean("category");
		category.setId("M001");
		category.setName("MEN");
		category.setDescription("ALL TYPES OF GLASSES FOR MEN");
		
		   catd.saveOrUpdate(category);

		   
		   if(catd.get("hjshs")== null)
		   {
			   System.out.println("Category does not exist");
		   }
		   else
		   {
			   System.out.println("Category exists, the details are");
			   System.out.println();
			   
		   }
	}
}
